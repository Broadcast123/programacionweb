<?php

define('DIRECTORIO_ARCHIVOS', 'archivos/');
