const $tablaArchivos = $('#tablaArchivos');

$tablaArchivos.load('ajax/tabla_archivos.php');
