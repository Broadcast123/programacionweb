<?php

include 'config.php';
include 'db.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($id === NULL || $id === false) {
	header('Location: ../Practica07/');
	exit();
}

$done = filter_input(INPUT_GET, 'done', FILTER_VALIDATE_INT);
if ($done === NULL || $done === false) {
	header('Location: ../Practica07/');
	exit();
}

$doneDb = $done != 0;

// Obtención del objeto PDO para la interaccion con DB.
$db = getPdo();  

//Actualizar el registro.
$sqlCmd = 'UPDATE todos SET done = :done WHERE id = :id';

// Obtención del objeto Statement para hacer la ejecución a la DB.
$stmt = $db->prepare($sqlCmd);

$stmt->bindParam(':done', $doneDb);
$stmt->bindParam(':id', $id);
$stmt->execute();

header('Location: ../Practica07/');
