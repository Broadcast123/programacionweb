<?php

include 'config.php';
include 'db.php';

$db = getPdo();

$sqlCmd = 'SELECT id, todo, done FROM todos';
$stmt = $db->prepare($sqlCmd);
$stmt->execute();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <title>Práctica 07: ToDo App</title>
</head>
<body>
<div id="contenedor">

    <h3>Practica 07: ToDo App</h3>

    <form action="add_todo.php" method="POST">
        <label for="txtTodo">TODO:</label>
        <input id="txtTodo" name="todo" type="text" required="required" />
        <br />
        <input type="submit" value="Agregar" />
    </form>

    <table style="border-colapse: colapse;">
        <thead>
            <tr>
                <th>Todo</th><th>Done?</th><th>Mark</th><th>Delete</th>
            </tr>
        </thead>
        <tbody>
<?php while($r = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
            <tr>
                <td style="border: 1px solid black; width: 300px;"><?= $r['todo'] ?></td>
                <td style="border: 1px solid black; text-align: center;"><?= $r['done'] != '0' ? 'YES' : 'NO' ?></td>
                <td style="border: 1px solid black;">
                    <a href="done_todo.php?id=<?=$r['id']?>&done=<?=$r['done'] == '0' ? '1' : '0'?>">MARK</a>
                </td>
                <td style="border: 1px solid black;">
                    <a href="delete_todo.php?id=<?=$r['id']?>">DELETE</a>
                </td>
            </tr>
<?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>