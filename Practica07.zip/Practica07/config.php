<?php

define('DIRECTORIO_ARCHIVOS', '/Users/EnriqueMartinez/Documents/');

// Configuraciones de Base de Datos.
define('DB_SERVER', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'test');
define('DB_PORT', 3306);

date_default_timezone_set('America/Mexico_City');
